package problem_statement1_1;

import java.util.Scanner;

public class EvenNumbers {

	public static void main(String[] args) {
		int n ;
        Scanner s=new Scanner(System.in);
		System.out.println("Even  the Numbers  ");
        n=s.nextInt();
		for (int i = 1; i <= n; i++) {

		   //if number%2 == 0 it means its an even number

		   if (i % 2 == 0) {

		 System.out.println(i );

		   }
		   }
	}

}
